<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('transaksi', function (Blueprint $table) {
            $table->id('id_transaksi');
            $table->string('kode_invoice', 50)->unique();
            
            // Foreign key ke tabel users (pengguna/kasir)
            $table->foreignId('id_pengguna')->nullable()->constrained('users')->onDelete('set null');

            $table->decimal('total_harga', 10, 2);
            $table->decimal('jumlah_bayar', 10, 2);
            $table->decimal('kembalian', 10, 2);
            $table->enum('metode_pembayaran', ['Tunai', 'Debit', 'QRIS']);
            
            // Menggunakan timestamps() agar otomatis ada created_at dan updated_at
            // tanggal_transaksi akan di-handle oleh created_at
            $table->timestamps(); 
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('transaksi');
    }
};