<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // UBAH 'users' MENJADI 'pengguna'
        Schema::create('pengguna', function (Blueprint $table) {
            // UBAH $table->id(); MENJADI increments('id_pengguna')
            $table->increments('id_pengguna'); // Primary key auto-increment untuk id_pengguna

            $table->string('nama_lengkap', 150);
            $table->string('username', 50)->unique();
            // HAPUS kolom email dan email_verified_at jika tidak ada di tabel native Anda
            // $table->string('email')->unique()->nullable();
            // $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->enum('level', ['admin', 'kasir'])->default('kasir');
            $table->rememberToken();
            // HAPUS $table->timestamps(); jika tabel native 'pengguna' tidak memiliki created_at/updated_at
            // $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // UBAH 'users' MENJADI 'pengguna'
        Schema::dropIfExists('pengguna');
    }
};