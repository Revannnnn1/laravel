<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User; // Pastikan ini ada

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'nama_lengkap' => 'surtzy', // Gunakan nama_lengkap
            'username' => 'surtzy',           // Gunakan username
            'email' => 'surtzy@gmail.com',
            'password' => Hash::make('sur12345'), // Password: password
            'level' => 'admin', // Pastikan kolom 'level' juga diisi jika itu ENUM dan tidak nullable
        ]);

        // Tambahkan user lain jika diperlukan
        User::create([
            'nama_lengkap' => 'vahn',
            'username' => 'vahn',
            'email' => 'vahn@gmail.com',
            'password' => Hash::make('van12345'),
            'level' => 'kasir', // Contoh level lain
        ]);
    }
}