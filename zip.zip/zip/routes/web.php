<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

// Import semua Controller aplikasi Anda di sini
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\ProdukController;
use App\Http\Controllers\SupplierController;
use App\Http\Controllers\TransaksiController;
use App\Http\Controllers\UserController;     // Untuk Manajemen Pengguna
use App\Http\Controllers\ReportController;    // Untuk Laporan
use App\Http\Controllers\Auth\AuthenticatedSessionController; // Untuk logout

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Route untuk halaman utama/welcome page
// Anda bisa mengubah ini untuk redirect ke login/dashboard jika sudah terautentikasi
Route::get('/', function () {
    return view('welcome');
});

// Route Dashboard setelah login
Route::get('/dashboard', [DashboardController::class, 'index'])
    ->middleware(['auth', 'verified']) // 'verified' adalah middleware Breeze untuk memastikan email terverifikasi
    ->name('dashboard');

// Route Profil Pengguna (bawaan Laravel Breeze)
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Route Logout (jika menggunakan method POST dari form di sidebar)
    // Jika logout bawaan Breeze sudah cukup (yang biasanya GET atau POST ke /logout),
    // Anda bisa biarkan require __DIR__.'/auth.php'; yang menanganinya.
    // Tapi jika Anda membuat form logout POST sendiri, ini penting.
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy']) // Menggunakan controller bawaan Breeze untuk logout
        ->name('logout');
});

// Autentikasi routes (login, register, dll.) dari Laravel Breeze
require __DIR__.'/auth.php';

// =============================================================
// Route Aplikasi Kasir Kosmetik Anda (Membutuhkan Login)
// =============================================================
Route::middleware(['auth'])->group(function () {
    // Route untuk Produk (Resource Controller - CRUD)
    Route::resource('produk', ProdukController::class);

    // Route untuk Kategori (Resource Controller - CRUD)
    Route::resource('kategori', KategoriController::class);

    // Route untuk Supplier (Resource Controller - CRUD)
    Route::resource('supplier', SupplierController::class);

    // Route untuk Transaksi (Custom Routes, karena tidak sepenuhnya mengikuti RESTful Resource)
    Route::get('transaksi/kasir', [TransaksiController::class, 'kasir'])->name('transaksi.kasir');
    Route::post('transaksi/store', [TransaksiController::class, 'storeTransaction'])->name('transaksi.store'); // Untuk menyimpan transaksi dari halaman kasir
    Route::get('transaksi/histori', [TransaksiController::class, 'histori'])->name('transaksi.histori');
    Route::get('transaksi/cetak_struk/{transaction}', [TransaksiController::class, 'cetakStruk'])->name('transaksi.cetak_struk');

    // =============================================================
    // Route Khusus Admin (Membutuhkan Login DAN Role Admin)
    // =============================================================
    // Asumsi Anda memiliki middleware 'admin' yang sudah terdaftar di Kernel.php
    // Jika Anda belum membuat middleware admin, silakan buat seperti panduan sebelumnya.
    Route::middleware(['admin'])->group(function () {
        // Route untuk Manajemen Pengguna (Resource Controller - CRUD)
        Route::resource('pengguna', UserController::class);

        // Route untuk Laporan
        Route::get('laporan/penjualan', [ReportController::class, 'penjualan'])->name('laporan.penjualan');
        Route::get('laporan/stok', [ReportController::class, 'stok'])->name('laporan.stok');
    });
});