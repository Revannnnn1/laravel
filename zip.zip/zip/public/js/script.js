// Menjalankan skrip setelah seluruh konten halaman dimuat
document.addEventListener('DOMContentLoaded', function() {

    // --- Fungsi Konfirmasi Hapus ---
    // Mencari semua tombol/link yang memiliki class .btn-hapus
    const deleteButtons = document.querySelectorAll('.btn-hapus');
    
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            // Mencegah link langsung dieksekusi
            event.preventDefault(); 

            // Menampilkan dialog konfirmasi bawaan browser
            const userConfirmed = confirm('Apakah Anda yakin ingin menghapus data ini?');
            
            // Jika pengguna mengklik "OK", maka lanjutkan ke URL hapus
            if (userConfirmed) {
                window.location.href = this.href;
            }
            // Jika pengguna mengklik "Cancel", tidak terjadi apa-apa
        });
    });

    // --- Fungsi untuk Menutup Alert/Notifikasi ---
    const alertBoxes = document.querySelectorAll('.alert .close-btn');

    alertBoxes.forEach(button => {
        button.addEventListener('click', function() {
            // Mengambil elemen .alert terdekat dan menyembunyikannya
            this.closest('.alert').style.display = 'none';
        });
    });

    // --- Fungsi untuk Memberi Tanda Aktif pada Menu Sidebar ---
    const currentUrl = window.location.href;
    const sidebarLinks = document.querySelectorAll('.sidebar .menu a');

    sidebarLinks.forEach(link => {
        // Jika URL link sama dengan URL halaman saat ini
        if (link.href === currentUrl) {
            link.classList.add('active');
        }
    });

});