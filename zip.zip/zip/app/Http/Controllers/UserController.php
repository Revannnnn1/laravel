<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    private function checkAdmin()
    {
        if (!Auth::check() || Auth::user()->level != 'admin') {
            return redirect()->route('dashboard')->with('flash_message', ['type' => 'danger', 'message' => 'Akses ditolak. Halaman ini hanya untuk Admin.']);
        }
        return true;
    }

    public function index()
    {
        if ($response = $this->checkAdmin()) { return $response; }
        $users = User::orderBy('nama_lengkap')->get();
        return view('pengguna.index', compact('users'));
    }

    public function create()
    {
        if ($response = $this->checkAdmin()) { return $response; }
        return view('pengguna.create');
    }

    public function store(Request $request)
    {
        if ($response = $this->checkAdmin()) { return $response; }

        $request->validate([
            'nama_lengkap' => 'required|string|max:150',
            'username' => 'required|string|max:50|unique:pengguna',
            'password' => 'required|string|min:3',
            'level' => 'required|in:admin,kasir',
        ]);

        User::create([
            'nama_lengkap' => $request->nama_lengkap,
            'username' => $request->username,
            'password' => Hash::make($request->password),
            'level' => $request->level,
        ]);

        return redirect()->route('pengguna.index')->with('flash_message', ['type' => 'success', 'message' => 'Pengguna baru berhasil ditambahkan!']);
    }

    public function edit(User $user)
    {
        if ($response = $this->checkAdmin()) { return $response; }
        return view('pengguna.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        if ($response = $this->checkAdmin()) { return $response; }

        $request->validate([
            'nama_lengkap' => 'required|string|max:150',
            'username' => 'required|string|max:50|unique:pengguna,username,'.$user->id_pengguna.',id_pengguna',
            'password' => 'nullable|string|min:3',
            'level' => 'required|in:admin,kasir',
        ]);

        $userData = $request->except('password');
        if ($request->filled('password')) {
            $userData['password'] = Hash::make($request->password);
        }

        $user->update($userData);

        return redirect()->route('pengguna.index')->with('flash_message', ['type' => 'success', 'message' => 'Data pengguna berhasil diupdate!']);
    }

    public function destroy(User $user)
    {
        if ($response = $this->checkAdmin()) { return $response; }

        if ($user->id_pengguna == Auth::id()) {
            return redirect()->route('pengguna.index')->with('flash_message', ['type' => 'danger', 'message' => 'Anda tidak bisa menghapus akun Anda sendiri.']);
        }

        try {
            $user->delete();
            return redirect()->route('pengguna.index')->with('flash_message', ['type' => 'success', 'message' => 'Pengguna berhasil dihapus!']);
        } catch (\Exception $e) {
            return redirect()->route('pengguna.index')->with('flash_message', ['type' => 'danger', 'message' => 'Gagal menghapus pengguna.']);
        }
    }
}