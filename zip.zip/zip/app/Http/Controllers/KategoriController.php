<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class KategoriController extends Controller
{
    public function index()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $categories = Category::orderBy('nama_kategori')->get();
        return view('kategori.index', compact('categories'));
    }

    public function create()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        return view('kategori.create');
    }

    public function store(Request $request)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_kategori' => 'required|string|max:100|unique:kategori',
            'deskripsi' => 'nullable|string',
        ]);

        Category::create($request->all());

        return redirect()->route('kategori.index')->with('flash_message', ['type' => 'success', 'message' => 'Kategori berhasil ditambahkan!']);
    }

    public function edit(Category $kategori)
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        return view('kategori.edit', compact('kategori'));
    }

    public function update(Request $request, Category $kategori)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_kategori' => 'required|string|max:100|unique:kategori,nama_kategori,'.$kategori->id_kategori.',id_kategori',
            'deskripsi' => 'nullable|string',
        ]);

        $kategori->update($request->all());

        return redirect()->route('kategori.index')->with('flash_message', ['type' => 'success', 'message' => 'Kategori berhasil diupdate!']);
    }

    public function destroy(Category $kategori)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        try {
            $kategori->delete();
            return redirect()->route('kategori.index')->with('flash_message', ['type' => 'success', 'message' => 'Kategori berhasil dihapus!']);
        } catch (\Exception $e) {
            return redirect()->route('kategori.index')->with('flash_message', ['type' => 'danger', 'message' => 'Gagal menghapus kategori. Mungkin kategori ini masih digunakan oleh produk lain.']);
        }
    }
}