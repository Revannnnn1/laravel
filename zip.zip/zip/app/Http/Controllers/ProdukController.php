<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Category;
use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProdukController extends Controller
{
    public function index()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $products = Product::with(['category', 'supplier'])->orderBy('nama_produk')->get();
        return view('produk.index', compact('products'));
    }

    public function create()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $categories = Category::orderBy('nama_kategori')->get();
        $suppliers = Supplier::orderBy('nama_supplier')->get();
        return view('produk.create', compact('categories', 'suppliers'));
    }

    public function store(Request $request)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_produk' => 'required|string|max:200',
            'id_kategori' => 'nullable|exists:kategori,id_kategori',
            'id_supplier' => 'nullable|exists:supplier,id_supplier',
            'stok' => 'required|integer|min:0',
            'harga_beli' => 'required|numeric|min:0',
            'harga_jual' => 'required|numeric|min:0',
            'sku' => 'nullable|string|max:100|unique:produk',
        ]);

        Product::create($request->all());

        return redirect()->route('produk.index')->with('flash_message', ['type' => 'success', 'message' => 'Produk berhasil ditambahkan!']);
    }

    public function edit(Product $product)
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $categories = Category::orderBy('nama_kategori')->get();
        $suppliers = Supplier::orderBy('nama_supplier')->get();
        return view('produk.edit', compact('product', 'categories', 'suppliers'));
    }

    public function update(Request $request, Product $product)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_produk' => 'required|string|max:200',
            'id_kategori' => 'nullable|exists:kategori,id_kategori',
            'id_supplier' => 'nullable|exists:supplier,id_supplier',
            'stok' => 'required|integer|min:0',
            'harga_beli' => 'required|numeric|min:0',
            'harga_jual' => 'required|numeric|min:0',
            'sku' => 'nullable|string|max:100|unique:produk,sku,'.$product->id_produk.',id_produk',
        ]);

        $product->update($request->all());

        return redirect()->route('produk.index')->with('flash_message', ['type' => 'success', 'message' => 'Produk berhasil diupdate!']);
    }

    public function destroy(Product $product)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        try {
            $product->delete();
            return redirect()->route('produk.index')->with('flash_message', ['type' => 'success', 'message' => 'Produk berhasil dihapus!']);
        } catch (\Exception $e) {
            return redirect()->route('produk.index')->with('flash_message', ['type' => 'danger', 'message' => 'Gagal menghapus produk. Mungkin produk ini terkait dengan transaksi.']);
        }
    }
}