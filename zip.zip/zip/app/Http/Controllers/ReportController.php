<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class ReportController extends Controller
{
    private function checkAdmin()
    {
        if (!Auth::check() || Auth::user()->level != 'admin') {
            return redirect()->route('dashboard')->with('flash_message', ['type' => 'danger', 'message' => 'Akses ditolak. Halaman ini hanya untuk Admin.']);
        }
        return true;
    }

    public function penjualan(Request $request)
    {
        if ($response = $this->checkAdmin()) { return $response; }

        $tanggal_mulai = $request->input('tanggal_mulai', Carbon::now()->startOfMonth()->format('Y-m-d'));
        $tanggal_selesai = $request->input('tanggal_selesai', Carbon::now()->format('Y-m-d'));

        $transactions = Transaction::with('user')
                                ->whereBetween('tanggal_transaksi', [$tanggal_mulai . ' 00:00:00', $tanggal_selesai . ' 23:59:59'])
                                ->orderBy('tanggal_transaksi')
                                ->get();

        $total_pendapatan = $transactions->sum('total_harga');

        return view('laporan.penjualan', compact('transactions', 'total_pendapatan', 'tanggal_mulai', 'tanggal_selesai'));
    }

    public function stok()
    {
        if ($response = $this->checkAdmin()) { return $response; }

        $batas_stok_minimum = 10;
        $products = Product::with(['category', 'supplier'])
                            ->orderBy('stok')
                            ->orderBy('nama_produk')
                            ->get();

        $total_nilai_inventaris = $products->sum(function($product) {
            return $product->stok * $product->harga_beli;
        });

        return view('laporan.stok', compact('products', 'batas_stok_minimum', 'total_nilai_inventaris'));
    }
}