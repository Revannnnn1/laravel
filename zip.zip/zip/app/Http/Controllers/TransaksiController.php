<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Transaction;
use App\Models\TransactionDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;

class TransaksiController extends Controller
{
    public function kasir()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $products = Product::where('stok', '>', 0)->orderBy('nama_produk')->get();
        return view('transaksi.kasir', compact('products'));
    }

    public function storeTransaction(Request $request)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'total_harga' => 'required|numeric|min:0',
            'jumlah_bayar' => 'required|numeric|min:0',
            'metode_pembayaran' => 'required|in:Tunai,Debit,QRIS',
            'items' => 'required|json',
        ]);

        $items = json_decode($request->items, true);

        if (empty($items)) {
            return redirect()->route('transaksi.kasir')->with('flash_message', ['type' => 'danger', 'message' => 'Terjadi kesalahan: Tidak ada item belanja.']);
        }

        DB::beginTransaction();

        try {
            $kode_invoice = 'INV-' . date('Ymd') . '-' . Str::upper(Str::random(8));

            $transaction = Transaction::create([
                'kode_invoice' => $kode_invoice,
                'id_pengguna' => Auth::id(),
                'total_harga' => $request->total_harga,
                'jumlah_bayar' => $request->jumlah_bayar,
                'kembalian' => $request->jumlah_bayar - $request->total_harga,
                'metode_pembayaran' => $request->metode_pembayaran,
            ]);

            if (!$transaction) {
                throw new \Exception("Gagal menyimpan data transaksi utama.");
            }

            foreach ($items as $item) {
                $product = Product::find($item['id_produk']);

                if (!$product || $product->stok < $item['jumlah']) {
                    DB::rollBack();
                    return redirect()->route('transaksi.kasir')->with('flash_message', ['type' => 'danger', 'message' => "Stok produk '{$product->nama_produk}' tidak cukup ({$product->stok})."]);
                }

                TransactionDetail::create([
                    'id_transaksi' => $transaction->id_transaksi,
                    'id_produk' => $item['id_produk'],
                    'jumlah' => $item['jumlah'],
                    'harga_saat_transaksi' => $item['harga_saat_transaksi'],
                    'subtotal' => $item['jumlah'] * $item['harga_saat_transaksi'],
                ]);

                $product->decrement('stok', $item['jumlah']);
            }

            DB::commit();

            return redirect()->route('transaksi.cetak_struk', $transaction->id_transaksi)->with('flash_message', ['type' => 'success', 'message' => 'Transaksi berhasil disimpan!']);

        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->route('transaksi.kasir')->with('flash_message', ['type' => 'danger', 'message' => 'Transaksi Gagal! Terjadi kesalahan: ' . $e->getMessage()]);
        }
    }

    public function histori()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $transactions = Transaction::with('user')->orderByDesc('tanggal_transaksi')->get();
        return view('transaksi.histori', compact('transactions'));
    }

    public function cetakStruk(Transaction $transaction)
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $transaction->load(['user', 'details.product']);
        return view('transaksi.cetak_struk', compact('transaction'));
    }
}