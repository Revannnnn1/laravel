<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        // Memastikan hanya user yang sudah login bisa mengakses
        if (!Auth::check()) {
            return redirect()->route('login');
        }

        // Ambil data untuk statistik dashboard
        // 1. Total Produk
        $total_produk = Product::count();

        // 2. Total Transaksi Hari Ini
        $total_trans_today = Transaction::whereDate('tanggal_transaksi', Carbon::today())->count();

        // 3. Total Pendapatan Hari Ini
        $total_pendapatan_today = Transaction::whereDate('tanggal_transaksi', Carbon::today())->sum('total_harga');

        // 4. Produk akan habis (stok <= 10)
        $produk_hampir_habis = Product::where('stok', '<=', 10)->count();

        return view('dashboard', compact('total_produk', 'total_trans_today', 'total_pendapatan_today', 'produk_hampir_habis'));
    }
}