<?php

namespace App\Http\Controllers;

use App\Models\Supplier;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class SupplierController extends Controller
{
    public function index()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        $suppliers = Supplier::orderBy('nama_supplier')->get();
        return view('supplier.index', compact('suppliers'));
    }

    public function create()
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        return view('supplier.create');
    }

    public function store(Request $request)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_supplier' => 'required|string|max:150',
            'no_telepon' => 'nullable|string|max:20',
            'alamat' => 'nullable|string',
        ]);

        Supplier::create($request->all());

        return redirect()->route('supplier.index')->with('flash_message', ['type' => 'success', 'message' => 'Supplier berhasil ditambahkan!']);
    }

    public function edit(Supplier $supplier)
    {
        if (!Auth::check()) { return redirect()->route('login'); }
        return view('supplier.edit', compact('supplier'));
    }

    public function update(Request $request, Supplier $supplier)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        $request->validate([
            'nama_supplier' => 'required|string|max:150',
            'no_telepon' => 'nullable|string|max:20',
            'alamat' => 'nullable|string',
        ]);

        $supplier->update($request->all());

        return redirect()->route('supplier.index')->with('flash_message', ['type' => 'success', 'message' => 'Supplier berhasil diupdate!']);
    }

    public function destroy(Supplier $supplier)
    {
        if (!Auth::check()) { return redirect()->route('login'); }

        try {
            $supplier->delete();
            return redirect()->route('supplier.index')->with('flash_message', ['type' => 'success', 'message' => 'Supplier berhasil dihapus!']);
        } catch (\Exception $e) {
            return redirect()->route('supplier.index')->with('flash_message', ['type' => 'danger', 'message' => 'Gagal menghapus supplier. Mungkin supplier ini masih digunakan oleh produk lain.']);
        }
    }
}