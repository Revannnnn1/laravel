<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Kategori extends Model
{
    use HasFactory;

    protected $table = 'kategori'; // Nama tabel di database
    protected $primaryKey = 'id_kategori'; // Primary key tabel
    public $timestamps = false; // Tabel ini tidak punya kolom created_at/updated_at

    // Kolom yang boleh diisi secara massal (mass assignment)
    protected $fillable = [
        'nama_kategori',
        'deskripsi'
    ];

    // RELASI: Satu Kategori bisa dimiliki oleh banyak Produk
    public function produk()
    {
        return $this->hasMany(Produk::class, 'id_kategori', 'id_kategori');
    }
}