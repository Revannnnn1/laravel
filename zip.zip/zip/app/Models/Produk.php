<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Produk extends Model
{
    use HasFactory;

    protected $table = 'produk';
    protected $primaryKey = 'id_produk';
    // Timestamps tidak perlu di-disable karena migrasi kita membuatnya
    // Cukup hapus komentar di bawah jika Anda ingin mengaktifkan timestamps default Laravel
    // atau jika Anda sudah punya kolom created_at dan updated_at di migrasi
    // public $timestamps = false; // Hapus baris ini jika ada, atau pastikan ini tidak ada/bernilai true

    protected $fillable = [
        'nama_produk',
        'id_kategori',
        'id_supplier',
        'stok',
        'harga_beli',
        'harga_jual',
        'sku'
    ];

    // RELASI: Satu Produk "milik" satu Kategori
    public function category() // <--- Ubah nama method dari kategori() menjadi category() untuk konsistensi
    {
        // Pastikan Kategori::class diimport di bagian atas file
        return $this->belongsTo(Kategori::class, 'id_kategori', 'id_kategori'); // <--- TAMBAHKAN id_kategori di sini
    }

    // RELASI: Satu Produk "milik" satu Supplier
    public function supplier()
    {
        // Pastikan Supplier::class diimport di bagian atas file
        return $this->belongsTo(Supplier::class, 'id_supplier', 'id_supplier'); // <--- TAMBAHKAN id_supplier di sini
    }
}