<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaksi extends Model
{
    use HasFactory;

    protected $table = 'transaksi';
    protected $primaryKey = 'id_transaksi';
    public $timestamps = false; // <--- TAMBAHKAN BARIS INI

    protected $fillable = [
        'kode_invoice',
        'id_pengguna',
        'total_harga',
        'jumlah_bayar',
        'kembalian',
        'metode_pembayaran',
    ];

    // RELASI: Satu Transaksi "milik" satu User (kasir)
    public function user()
    {
        // Pastikan User::class diimport di bagian atas file
        return $this->belongsTo(User::class, 'id_pengguna', 'id_pengguna'); // <--- TAMBAHKAN id_pengguna di sini
    }

    // RELASI: Satu Transaksi bisa memiliki banyak item/detail
    public function details() // <--- Ubah nama method dari detailTransaksi() menjadi details() untuk konsistensi
    {
        // Pastikan DetailTransaksi::class diimport di bagian atas file
        return $this->hasMany(DetailTransaksi::class, 'id_transaksi', 'id_transaksi');
    }
}