@extends('layouts.app')

@section('title', 'Dashboard')
@section('page_title', 'Dashboard')

@section('content')
<div class="row">
    <div class="col-lg-3 col-6">
        <div class="card">
            <div class="card-body">
                <h3>{{ $total_produk }}</h3>
                <p>Total Jenis Produk</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="card">
            <div class="card-body">
                <h3>{{ $total_trans_today }}</h3>
                <p>Transaksi Hari Ini</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="card">
            <div class="card-body">
                <h3>Rp {{ number_format($total_pendapatan_today, 0, ',', '.') }}</h3>
                <p>Pendapatan Hari Ini</p>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-6">
        <div class="card">
            <div class="card-body">
                <h3>{{ $produk_hampir_habis }}</h3>
                <p>Produk Akan Habis</p>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <h2>Selamat Datang, {{ htmlspecialchars(Auth::user()->nama_lengkap ?? 'Tamu') }}!</h2>
        <p>Anda login sebagai <strong>{{ ucfirst(htmlspecialchars(Auth::user()->level ?? '')) }}</strong>.</p>
        <p>Gunakan menu di sebelah kiri untuk mengelola data toko Anda.</p>
    </div>
</div>
@endsection