@extends('layouts.app')

@section('title', 'Manajemen Pengguna')
@section('page_title', 'Daftar Pengguna Sistem')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Pengguna Sistem</h3>
        <div class="card-tools">
            <a href="{{ route('pengguna.create') }}" class="btn btn-primary">Tambah Pengguna</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Lengkap</th>
                    <th>Username</th>
                    <th>Level</th>
                    <th style="width: 150px">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>{{ $loop->iteration }}.</td>
                        <td>{{ htmlspecialchars($user->nama_lengkap) }}</td>
                        <td>{{ htmlspecialchars($user->username) }}</td>
                        <td>{{ ucfirst(htmlspecialchars($user->level)) }}</td>
                        <td>
                            <a href="{{ route('pengguna.edit', $user->id_pengguna) }}" class="btn btn-secondary btn-sm">Edit</a>
                            {{-- Mencegah admin menghapus akunnya sendiri --}}
                            @if ($user->id_pengguna != Auth::id())
                                <form action="{{ route('pengguna.destroy', $user->id_pengguna) }}" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                                </form>
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</div>
@endsection