@extends('layouts.app')

@section('title', 'Edit Pengguna')
@section('page_title', 'Edit Pengguna')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Form Edit Pengguna</h3>
    </div>
    <div class="card-body">
        <form action="{{ route('pengguna.update', $user->id_pengguna) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" class="form-control" name="nama_lengkap" value="{{ old('nama_lengkap', $user->nama_lengkap) }}" required>
            </div>
            <div class="form-group">
                <label>Username</label>
                <input type="text" class="form-control" name="username" value="{{ old('username', $user->username) }}" required>
            </div>
            <div class="form-group">
                <label>Password Baru</label>
                <input type="password" class="form-control" name="password">
                <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small>
            </div>
            <div class="form-group">
                <label>Level</label>
                <select name="level" class="form-control" required>
                    <option value="admin" {{ (old('level', $user->level) == 'admin') ? 'selected' : '' }}>Admin</option>
                    <option value="kasir" {{ (old('level', $user->level) == 'kasir') ? 'selected' : '' }}>Kasir</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Update</button>
            <a href="{{ route('pengguna.index') }}" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
@endsection