@extends('layouts.app')

@section('title', 'Data Kategori')
@section('page_title', 'Data Kategori')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Kategori Produk</h3>
        <div class="card-tools">
            <a href="{{ route('kategori.create') }}" class="btn btn-primary">Tambah Kategori</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Nama Kategori</th>
                    <th>Deskripsi</th>
                    <th style="width: 150px">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($categories as $category)
                    <tr>
                        <td>{{ $loop->iteration }}.</td>
                        <td>{{ htmlspecialchars($category->nama_kategori) }}</td>
                        <td>{{ htmlspecialchars($category->deskripsi) }}</td>
                        <td>
                            <a href="{{ route('kategori.edit', $category->id_kategori) }}" class="btn btn-secondary btn-sm">Edit</a>
                            <form action="{{ route('kategori.destroy', $category->id_kategori) }}" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" style="text-align: center;">Tidak ada data kategori.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection