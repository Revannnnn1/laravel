@extends('layouts.app')

@section('title', 'Data Supplier')
@section('page_title', 'Data Supplier')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Supplier</h3>
        <div class="card-tools">
            <a href="{{ route('supplier.create') }}" class="btn btn-primary">Tambah Supplier</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th style="width: 10px">#</th>
                    <th>Nama Supplier</th>
                    <th>No. Telepon</th>
                    <th>Alamat</th>
                    <th style="width: 150px">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($suppliers as $supplier)
                    <tr>
                        <td>{{ $loop->iteration }}.</td>
                        <td>{{ htmlspecialchars($supplier->nama_supplier) }}</td>
                        <td>{{ htmlspecialchars($supplier->no_telepon) }}</td>
                        <td>{{ htmlspecialchars($supplier->alamat) }}</td>
                        <td>
                            <a href="{{ route('supplier.edit', $supplier->id_supplier) }}" class="btn btn-secondary btn-sm">Edit</a>
                            <form action="{{ route('supplier.destroy', $supplier->id_supplier) }}" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" style="text-align: center;">Tidak ada data supplier.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection