@extends('layouts.app')

@section('title', 'Halaman Kasir')
@section('page_title', 'Halaman Kasir')

@section('content')
<form id="form-transaksi" action="{{ route('transaksi.store') }}" method="POST" onsubmit="return validasiForm()">
    @csrf
    <div class="row">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Keranjang Belanja</h3></div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Cari & Tambah Produk</label>
                        <select id="cari-produk" class="form-control">
                            <option value="">-- Ketik atau Pilih Produk --</option>
                            @foreach($products as $p)
                                <option value="{{ $p->id_produk }}"
                                        data-nama="{{ htmlspecialchars($p->nama_produk) }}"
                                        data-harga="{{ $p->harga_jual }}"
                                        data-stok="{{ $p->stok }}">
                                    {{ htmlspecialchars($p->nama_produk) }} (Stok: {{ $p->stok }})
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Produk</th>
                                <th>Harga</th>
                                <th style="width: 15%">Jumlah</th>
                                <th>Subtotal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody id="keranjang-belanja"></tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header"><h3 class="card-title">Pembayaran</h3></div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Total Belanja</label>
                        <input type="text" id="total-belanja" name="total_harga" class="form-control" value="Rp 0" readonly>
                    </div>
                    <div class="form-group">
                        <label for="metode_pembayaran">Metode Pembayaran</label>
                        <select class="form-control" name="metode_pembayaran" required>
                            <option value="Tunai">Tunai</option>
                            <option value="Debit">Debit</option>
                            <option value="QRIS">QRIS</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Jumlah Bayar</label>
                        <input type="number" id="jumlah-bayar" name="jumlah_bayar" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>Kembalian</label>
                        <input type="text" id="kembalian" name="kembalian" class="form-control" value="Rp 0" readonly>
                    </div>
                    <input type="hidden" name="items" id="items-json">
                    <button type="submit" class="btn btn-success btn-block">Selesaikan Transaksi</button>
                </div>
            </div>
        </div>
    </div>
</form>
@endsection

@section('scripts')
<script>
function formatRupiah(angka, prefix) {
    let number_string = String(angka).replace(/[^,\d]/g, ''),
        split = number_string.split(','),
        sisa = split[0].length % 3,
        rupiah = split[0].substr(0, sisa),
        ribuan = split[0].substr(sisa).match(/\d{3}/gi);
    if (ribuan) {
        separator = sisa ? '.' : '';
        rupiah += separator + ribuan.join('.');
    }
    rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
    return prefix == undefined ? rupiah : (rupiah ? 'Rp ' + rupiah : '');
}

function parseRupiah(rupiahString) {
    return parseFloat(String(rupiahString).replace(/Rp\s?|\./g, '').replace(',', '.')) || 0;
}

$(document).ready(function() {
    $('#cari-produk').select2({
        placeholder: "-- Ketik atau Pilih Produk --",
        allowClear: true
    });

    function updateTotal() {
        let total = 0;
        $('#keranjang-belanja tr').each(function() {
            total += parseRupiah($(this).find('.subtotal').text());
        });
        $('#total-belanja').val(formatRupiah(total, 'Rp '));
        updateKembalian();
    }

    function updateKembalian() {
        let total = parseRupiah($('#total-belanja').val()) || 0;
        let bayar = parseFloat($('#jumlah-bayar').val()) || 0;
        let kembalian = bayar - total;
        $('#kembalian').val(formatRupiah(kembalian > 0 ? kembalian : 0, 'Rp '));
    }

    $('#cari-produk').on('select2:select', function(e) {
        let selected = $(this).find(':selected');
        let id = selected.val();
        if (!id) return;

        if ($('#keranjang-belanja tr[data-id="' + id + '"]').length > 0) {
            alert('Produk sudah ada di keranjang!');
            $(this).val('').trigger('change');
            return;
        }

        let nama = selected.data('nama');
        let harga = parseFloat(selected.data('harga'));
        let stok = parseInt(selected.data('stok'));

        if (stok <= 0) {
            alert('Produk ini sedang kosong (stok 0).');
            $(this).val('').trigger('change');
            return;
        }

        let itemHtml = `<tr data-id="${id}">
                            <td>${nama}</td>
                            <td class="harga">${formatRupiah(harga, 'Rp ')}</td>
                            <td>
                                <input type="number" class="form-control jumlah" value="1" min="1" max="${stok}" data-harga="${harga}">
                            </td>
                            <td class="subtotal">${formatRupiah(harga, 'Rp ')}</td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm hapus-item">&times;</button>
                            </td>
                        </tr>`;
        $('#keranjang-belanja').append(itemHtml);
        updateTotal();
        $(this).val('').trigger('change');
    });

    $(document).on('input', '.jumlah', function() {
        let jumlah = parseInt($(this).val());
        let stok = parseInt($(this).attr('max'));
        let harga = parseFloat($(this).data('harga'));

        if (isNaN(jumlah) || jumlah < 1) {
            $(this).val(1);
            jumlah = 1;
        }
        if (jumlah > stok) {
            alert('Jumlah melebihi stok (' + stok + ')');
            $(this).val(stok);
            jumlah = stok;
        }

        let subtotal = jumlah * harga;
        $(this).closest('tr').find('.subtotal').text(formatRupiah(subtotal, 'Rp '));
        updateTotal();
    });

    $(document).on('click', '.hapus-item', function() {
        $(this).closest('tr').remove();
        updateTotal();
    });

    $('#jumlah-bayar').on('input', updateKembalian);
});

function validasiForm() {
    let items = [];
    $('#keranjang-belanja tr').each(function() {
        items.push({
            id_produk: $(this).data('id'),
            jumlah: parseInt($(this).find('.jumlah').val()),
            harga_saat_transaksi: parseFloat($(this).find('.jumlah').data('harga'))
        });
    });

    if (items.length === 0) {
        alert('Keranjang belanja masih kosong!');
        return false;
    }

    let allStokOk = true;
    $('#keranjang-belanja tr').each(function() {
        let id_produk = $(this).data('id');
        let jumlah_diminta = parseInt($(this).find('.jumlah').val());
        let stok_tersedia = parseInt($(this).find('.jumlah').attr('max'));

        if (jumlah_diminta > stok_tersedia) {
            alert(`Jumlah produk ${$(this).find('td:first').text()} melebihi stok yang tersedia (${stok_tersedia}). Silakan sesuaikan.`);
            allStokOk = false;
            return false;
        }
    });

    if (!allStokOk) {
        return false;
    }

    let totalBelanja = parseRupiah($('#total-belanja').val()) || 0;
    let jumlahBayar = parseFloat($('#jumlah-bayar').val()) || 0;

    if (jumlahBayar < totalBelanja) {
        alert('Jumlah bayar kurang dari total belanja!');
        return false;
    }

    $('#items-json').val(JSON.stringify(items));
    return true;
}
</script>
@endsection