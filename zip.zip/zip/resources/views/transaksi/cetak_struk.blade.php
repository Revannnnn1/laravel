@extends('layouts.app')

@section('title', 'Struk Belanja')
@section('page_title', 'Detail Transaksi')

@section('content')
<style>
    /* CSS khusus untuk halaman cetak, menyembunyikan elemen yang tidak perlu */
    @media print {
        .wrapper .sidebar, .header, .btn, footer, .card-header a {
            display: none !important;
        }
        .wrapper .main-content { width: 100% !important; margin: 0 !important; padding: 0 !important; }
        .content { padding: 0 !important; }
        .card { border: none !important; box-shadow: none !important; }
    }
</style>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Detail Transaksi</h3>
        <a href="javascript:window.print()" class="btn btn-success float-right">Cetak Struk</a>
    </div>
    <div class="card-body">
        <div style="text-align: center; margin-bottom: 20px;">
            <h4>Toko Cantik</h4>
            <p>Jl. Merdeka No. 123, Kuningan, Jawa Barat</p>
        </div>
        <hr>
        <p>
            No. Invoice: {{ htmlspecialchars($transaction->kode_invoice) }}<br>
            Tanggal: {{ \Carbon\Carbon::parse($transaction->tanggal_transaksi)->format('d M Y, H:i') }}<br>
            Kasir: {{ htmlspecialchars($transaction->user->nama_lengkap ?? 'N/A') }}
        </p>
        <hr>
        <table class="table">
            <thead>
                <tr>
                    <th>Produk</th>
                    <th style="text-align: right;">Harga</th>
                    <th style="text-align: center;">Jumlah</th>
                    <th style="text-align: right;">Subtotal</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transaction->details as $item)
                <tr>
                    <td>{{ htmlspecialchars($item->product->nama_produk ?? 'Produk Tidak Ditemukan') }}</td>
                    <td style="text-align: right;">Rp {{ number_format($item->harga_saat_transaksi, 0, ',', '.') }}</td>
                    <td style="text-align: center;">{{ $item->jumlah }}</td>
                    <td style="text-align: right;">Rp {{ number_format($item->subtotal, 0, ',', '.') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
        <hr>
        <div style="text-align: right;">
            <p><strong>Total: Rp {{ number_format($transaction->total_harga, 0, ',', '.') }}</strong></p>
            <p>Bayar: Rp {{ number_format($transaction->jumlah_bayar, 0, ',', '.') }}</p>
            <p>Kembali: Rp {{ number_format($transaction->kembalian, 0, ',', '.') }}</p>
        </div>
        <hr>
        <p class="text-center" style="margin-top: 20px;">Terima kasih telah berbelanja!</p>
    </div>
</div>
@endsection