@extends('layouts.app')

@section('title', 'Riwayat Transaksi')
@section('page_title', 'Daftar Semua Transaksi')

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Daftar Semua Transaksi</h3></div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Invoice</th>
                    <th>Tanggal</th>
                    <th>Kasir</th>
                    <th>Total Belanja</th>
                    <th>Metode Bayar</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($transactions as $transaction)
                <tr>
                    <td>{{ htmlspecialchars($transaction->kode_invoice) }}</td>
                    <td>{{ \Carbon\Carbon::parse($transaction->tanggal_transaksi)->format('d M Y, H:i') }}</td>
                    <td>{{ htmlspecialchars($transaction->user->nama_lengkap ?? 'N/A') }}</td>
                    <td>Rp {{ number_format($transaction->total_harga, 0, ',', '.') }}</td>
                    <td>{{ htmlspecialchars($transaction->metode_pembayaran) }}</td>
                    <td>
                        <a href="{{ route('transaksi.cetak_struk', $transaction->id_transaksi) }}" class="btn btn-info btn-sm">Lihat Struk</a>
                    </td>
                </tr>
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center;">Tidak ada riwayat transaksi.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection