<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Dashboard') - Toko Cantik</title>

    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/select2.min.css') }}">

    <script src="{{ asset('assets/js/jquery-3.7.1.min.js') }}"></script>

    </head>
<body>
    <div class="wrapper">
        @include('partials.sidebar') {{-- Memuat sidebar partial --}}

        <div class="main-content">
            @include('partials.header_main_content') {{-- Memuat header partial --}}

            <main class="content">
                {{-- Flash message dari Session (pengganti display_flash_message dari native) --}}
                @if(session('flash_message'))
                    <div class="alert alert-{{ session('flash_message.type') }}">
                        {{ session('flash_message.message') }}
                        <button type="button" class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
                    </div>
                @endif

                @yield('content') {{-- Konten spesifik halaman akan di-inject di sini --}}
            </main>

            @include('partials.footer_main_content') {{-- Memuat footer partial --}}
        </div>
    </div>

    <script src="{{ asset('assets/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/js/script.js') }}"></script>

    @yield('scripts') {{-- Untuk script JS khusus halaman, misalnya inisialisasi Select2 di halaman tertentu --}}
</body>
</html>