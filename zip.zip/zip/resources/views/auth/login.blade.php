<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Kasir Kosmetik</title>
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: var(--background-color);
        }
        .login-card {
            width: 100%;
            max-width: 400px;
        }
    </style>
    {{-- Laravel Breeze sering menyertakan CSS tambahan melalui @vite. --}}
    {{-- Jika Anda ingin memastikan CSS custom Anda yang menang, pastikan style.css dimuat TERAKHIR --}}
    {{-- Atau pastikan CSS Anda memiliki spesifisitas yang lebih tinggi. --}}
    {{-- Untuk kasus login ini, saya menempatkan style.css langsung agar terpisah dari @vite default Breeze. --}}
</head>
<body>
    <div class="card login-card">
        <div class="card-body">
            <h2 class="text-center mb-4">Login Aplikasi</h2>

            {{-- Status sukses dari redirect setelah logout --}}
            @if(session('status'))
                <div class="alert alert-success">
                    {{ session('status') }}
                    <button type="button" class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
                </div>
            @endif

            {{-- Flash message dari controller jika ada --}}
            @if(session('flash_message'))
                <div class="alert alert-{{ session('flash_message.type') }}">
                    {{ session('flash_message.message') }}
                    <button type="button" class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
                </div>
            @endif

            {{-- Error validasi dari Laravel --}}
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                    <button type="button" class="close-btn" onclick="this.parentElement.style.display='none'">&times;</button>
                </div>
            @endif

            <form action="{{ route('login') }}" method="POST">
                @csrf
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" name="username" class="form-control" value="{{ old('username') }}" required>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" name="password" class="form-control" required>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login</button>
            </form>
        </div>
    </div>
    {{-- Untuk halaman login yang minimal, kita tidak perlu memuat semua JS utama Laravel/Breeze. --}}
    {{-- Jika ada script JS spesifik untuk halaman ini, bisa ditambahkan di sini. --}}
    {{-- Contoh: <script src="{{ asset('assets/js/script.js') }}"></script> --}}
</body>
</html>