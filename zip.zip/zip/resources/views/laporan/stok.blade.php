@extends('layouts.app')

@section('title', 'Laporan Stok Barang')
@section('page_title', 'Laporan Stok Barang')

@section('content')
<style>
/* Sembunyikan elemen yang tidak perlu saat mencetak */
@media print {
    .wrapper .sidebar, .header, .btn, footer, .card-header form {
        display: none !important;
    }
    .card-header .print-title { display: block !important; text-align: center; }
    .wrapper .main-content { width: 100% !important; margin: 0 !important; padding: 0 !important; }
    .content { padding: 0 !important; }
    .card { border: none !important; box-shadow: none !important; }
}
.print-title { display: none; }
</style>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Laporan Stok Barang Saat Ini</h3>
        <div class="print-title">
            <h3>Laporan Stok Barang</h3>
            <p>Per Tanggal: {{ date('d M Y') }}</p>
        </div>
        <div class="card-tools">
            <a href="javascript:window.print()" class="btn btn-success">Cetak Laporan</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>SKU</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Stok</th>
                    <th>Harga Beli</th>
                    <th>Nilai Inventaris</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $product)
                    @php
                        $nilai_inventaris = $product->stok * $product->harga_beli;
                        $row_class = $product->stok <= $batas_stok_minimum ? 'table-danger' : '';
                    @endphp
                    <tr class="{{ $row_class }}">
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ htmlspecialchars($product->sku) }}</td>
                        <td>{{ htmlspecialchars($product->nama_produk) }}</td>
                        <td>{{ htmlspecialchars($product->category->nama_kategori ?? 'N/A') }}</td>
                        <td style="text-align: center; font-weight: bold;">{{ $product->stok }}</td>
                        <td style="text-align: right;">Rp {{ number_format($product->harga_beli, 0, ',', '.') }}</td>
                        <td style="text-align: right;">Rp {{ number_format($nilai_inventaris, 0, ',', '.') }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada data produk.</td>
                    </tr>
                @endforelse
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="6" style="text-align: right;">Total Nilai Seluruh Inventaris</th>
                    <th style="text-align: right;">Rp {{ number_format($total_nilai_inventaris, 0, ',', '.') }}</th>
                </tr>
            </tfoot>
        </table>
        <p class="mt-3 text-muted">*Baris berwarna merah menandakan stok produk di bawah atau sama dengan {{ $batas_stok_minimum }}.</p>
    </div>
</div>
@endsection