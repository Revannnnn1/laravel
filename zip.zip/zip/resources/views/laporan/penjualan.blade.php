@extends('layouts.app')

@section('title', 'Laporan Penjualan')
@section('page_title', 'Laporan Penjualan')

@section('content')
<style>
/* Sembunyikan elemen yang tidak perlu saat mencetak */
@media print {
    .wrapper .sidebar, .header, .btn, footer, .card-header .form-inline, .card-header h3 {
        display: none !important;
    }
    .card-header .print-title { display: block !important; text-align: center; }
    .wrapper .main-content { width: 100% !important; margin: 0 !important; padding: 0 !important; }
    .content { padding: 0 !important; }
    .card { border: none !important; box-shadow: none !important; }
}
.print-title { display: none; }
</style>

<div class="card">
    <div class="card-header">
        <h3 class="card-title">Filter Laporan Penjualan</h3>
        <div class="print-title">
            <h3>Laporan Penjualan</h3>
            <p>Periode: {{ \Carbon\Carbon::parse($tanggal_mulai)->format('d M Y') }} - {{ \Carbon\Carbon::parse($tanggal_selesai)->format('d M Y') }}</p>
        </div>
        <div class="card-tools">
            <form action="{{ route('laporan.penjualan') }}" method="GET" class="form-inline">
                <label for="tanggal_mulai" class="mr-2">Dari</label>
                <input type="date" name="tanggal_mulai" class="form-control mr-2" value="{{ $tanggal_mulai }}">
                <label for="tanggal_selesai" class="mr-2">Sampai</label>
                <input type="date" name="tanggal_selesai" class="form-control mr-2" value="{{ $tanggal_selesai }}">
                <button type="submit" class="btn btn-primary">Tampilkan</button>
                <a href="javascript:window.print()" class="btn btn-success ml-2">Cetak</a>
            </form>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Invoice</th>
                    <th>Tanggal</th>
                    <th>Kasir</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                @forelse($transactions as $transaction)
                    <tr>
                        <td>{{ $loop->iteration }}</td>
                        <td>{{ htmlspecialchars($transaction->kode_invoice) }}</td>
                        <td>{{ \Carbon\Carbon::parse($transaction->tanggal_transaksi)->format('d M Y, H:i') }}</td>
                        <td>{{ htmlspecialchars($transaction->user->nama_lengkap ?? 'N/A') }}</td>
                        <td style="text-align: right;">Rp {{ number_format($transaction->total_harga, 0, ',', '.') }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" class="text-center">Tidak ada data transaksi pada periode ini.</td>
                    </tr>
                @endforelse
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="4" style="text-align: right;">Total Pendapatan</th>
                    <th style="text-align: right;">Rp {{ number_format($total_pendapatan, 0, ',', '.') }}</th>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
@endsection