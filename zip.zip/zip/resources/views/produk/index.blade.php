@extends('layouts.app')

@section('title', 'Data Produk')
@section('page_title', 'Data Produk')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Daftar Produk</h3>
        <div class="card-tools">
            <a href="{{ route('produk.create') }}" class="btn btn-primary">Tambah Produk</a>
        </div>
    </div>
    <div class="card-body">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th>Supplier</th>
                    <th>Stok</th>
                    <th>Harga Jual</th>
                    <th style="width: 150px">Aksi</th>
                </tr>
            </thead>
            <tbody>
                @forelse($products as $product)
                    <tr>
                        <td>{{ $loop->iteration }}.</td>
                        <td>{{ htmlspecialchars($product->nama_produk) }}</td>
                        <td>{{ htmlspecialchars($product->category->nama_kategori ?? 'N/A') }}</td>
                        <td>{{ htmlspecialchars($product->supplier->nama_supplier ?? 'N/A') }}</td>
                        <td>{{ $product->stok }}</td>
                        <td>Rp {{ number_format($product->harga_jual, 0, ',', '.') }}</td>
                        <td>
                            <a href="{{ route('produk.edit', $product->id_produk) }}" class="btn btn-secondary btn-sm">Edit</a>
                            <form action="{{ route('produk.destroy', $product->id_produk) }}" method="POST" style="display:inline;" onsubmit="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                                @csrf
                                @method('DELETE') {{-- Method spoofing untuk DELETE --}}
                                <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" style="text-align: center;">Tidak ada data produk.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection