@extends('layouts.app')

@section('title', 'Tambah Produk')
@section('page_title', 'Tambah Produk')

@section('content')
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Form Tambah Produk</h3>
    </div>
    <div class="card-body">
        <form action="{{ route('produk.store') }}" method="POST">
            @csrf {{-- Token CSRF untuk keamanan form --}}
            <div class="form-group">
                <label for="nama_produk">Nama Produk</label>
                <input type="text" class="form-control" name="nama_produk" value="{{ old('nama_produk') }}" required>
            </div>

            <div class="form-group">
                <label for="id_kategori">Kategori</label>
                <select class="form-control" name="id_kategori">
                    <option value="">-- Pilih Kategori --</option>
                    @foreach($categories as $category)
                        <option value="{{ $category->id_kategori }}" {{ old('id_kategori') == $category->id_kategori ? 'selected' : '' }}>
                            {{ htmlspecialchars($category->nama_kategori) }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="id_supplier">Supplier</label>
                <select class="form-control" name="id_supplier">
                    <option value="">-- Pilih Supplier --</option>
                    @foreach($suppliers as $supplier)
                        <option value="{{ $supplier->id_supplier }}" {{ old('id_supplier') == $supplier->id_supplier ? 'selected' : '' }}>
                            {{ htmlspecialchars($supplier->nama_supplier) }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="stok">Stok Awal</label>
                <input type="number" class="form-control" name="stok" value="{{ old('stok', 0) }}" required>
            </div>

            <div class="form-group">
                <label for="harga_beli">Harga Beli</label>
                <input type="number" step="0.01" class="form-control" name="harga_beli" value="{{ old('harga_beli') }}" required>
            </div>

            <div class="form-group">
                <label for="harga_jual">Harga Jual</label>
                <input type="number" step="0.01" class="form-control" name="harga_jual" value="{{ old('harga_jual') }}" required>
            </div>

            <div class="form-group">
                <label for="sku">SKU (Kode Barcode)</label>
                <input type="text" class="form-control" name="sku" value="{{ old('sku') }}">
            </div>

            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="{{ route('produk.index') }}" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
@endsection