@extends('layouts.app')

@section('title', 'Edit Produk')
@section('page_title', 'Edit Produk')

@section('content')
<div class="card">
    <div class="card-header"><h3 class="card-title">Form Edit Produk</h3></div>
    <div class="card-body">
        <form action="{{ route('produk.update', $product->id_produk) }}" method="POST">
            @csrf
            @method('PUT') {{-- Method spoofing untuk PUT (update) --}}

            <div class="form-group">
                <label>Nama Produk</label>
                <input type="text" class="form-control" name="nama_produk" value="{{ old('nama_produk', $product->nama_produk) }}" required>
            </div>

            <div class="form-group">
                <label>Kategori</label>
                <select class="form-control" name="id_kategori">
                    @foreach($categories as $category)
                        <option value="{{ $category->id_kategori }}" {{ (old('id_kategori', $product->id_kategori) == $category->id_kategori) ? 'selected' : '' }}>
                            {{ htmlspecialchars($category->nama_kategori) }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label>Supplier</label>
                <select class="form-control" name="id_supplier">
                    @foreach($suppliers as $supplier)
                        <option value="{{ $supplier->id_supplier }}" {{ (old('id_supplier', $product->id_supplier) == $supplier->id_supplier) ? 'selected' : '' }}>
                            {{ htmlspecialchars($supplier->nama_supplier) }}
                        </option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label>Stok</label>
                <input type="number" class="form-control" name="stok" value="{{ old('stok', $product->stok) }}" required>
            </div>

            <div class="form-group">
                <label>Harga Beli</label>
                <input type="number" step="0.01" class="form-control" name="harga_beli" value="{{ old('harga_beli', $product->harga_beli) }}" required>
            </div>

            <div class="form-group">
                <label>Harga Jual</label>
                <input type="number" step="0.01" class="form-control" name="harga_jual" value="{{ old('harga_jual', $product->harga_jual) }}" required>
            </div>

            <div class="form-group">
                <label>SKU (Kode Barcode)</label>
                <input type="text" class="form-control" name="sku" value="{{ old('sku', $product->sku) }}">
            </div>

            <button type="submit" class="btn btn-primary">Update</button>
            <a href="{{ route('produk.index') }}" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>
@endsection