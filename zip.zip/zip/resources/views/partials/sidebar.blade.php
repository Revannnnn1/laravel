<div class="sidebar">
    <div class="logo">
        <a href="{{ route('dashboard') }}">Toko Cantik</a>
    </div>
    <nav class="menu">
        {{-- Gunakan Request::is() untuk menandai menu aktif berdasarkan URL --}}
        <a href="{{ route('dashboard') }}" class="{{ Request::is('/') ? 'active' : '' }}">Dashboard</a>
        <a href="{{ route('transaksi.kasir') }}" class="{{ Request::is('transaksi/kasir') ? 'active' : '' }}">Kasir</a>
        <hr style="border-color: #4a5157; margin: 10px 0;">

        <strong style="color: #6c757d; padding: 0 15px; font-size:12px;">MASTER DATA</strong>
        <a href="{{ route('produk.index') }}" class="{{ Request::is('produk*') ? 'active' : '' }}">Data Produk</a>
        <a href="{{ route('kategori.index') }}" class="{{ Request::is('kategori*') ? 'active' : '' }}">Data Kategori</a>
        <a href="{{ route('supplier.index') }}" class="{{ Request::is('supplier*') ? 'active' : '' }}">Data Supplier</a>

        <hr style="border-color: #4a5157; margin: 10px 0;">

        <strong style="color: #6c757d; padding: 0 15px; font-size:12px;">LAPORAN & HISTORI</strong>
        <a href="{{ route('transaksi.histori') }}" class="{{ Request::is('transaksi/histori') ? 'active' : '' }}">Riwayat Transaksi</a>

        {{-- Hanya tampil jika user adalah admin. Sesuaikan dengan level di tabel 'pengguna' --}}
        @if(Auth::check() && Auth::user()->level == 'admin')
            <a href="{{ route('laporan.penjualan') }}" class="{{ Request::is('laporan/penjualan') ? 'active' : '' }}">Laporan Penjualan</a>
            <a href="{{ route('pengguna.index') }}" class="{{ Request::is('pengguna*') ? 'active' : '' }}">Manajemen Pengguna</a>
        @endif
    </nav>
</div>