<footer style="text-align: center; padding: 20px; font-size: 12px; color: #6c757d; border-top: 1px solid var(--border-color);">
    Copyright &copy; {{ date('Y') }} Toko Cantik. All Rights Reserved.
</footer>