<header class="header">
    <div class="header-title">
        <h3>@yield('page_title', 'Dashboard')</h3>
    </div>
    <div class="user-info">
        {{-- Auth::user() mengambil data user yang sedang login dari Laravel --}}
        <span>Halo, <strong>{{ Auth::user()->nama_lengkap ?? 'Tamu' }}</strong></span>
        {{-- Sesuaikan dengan route logout Anda, biasanya `route('logout')` dan pakai form POST --}}
        <form method="POST" action="{{ route('logout') }}" style="display:inline;">
            @csrf
            <button type="submit" class="btn btn-danger btn-sm">Logout</button>
        </form>
    </div>
</header>